from rest_framework import serializers
from server.models import Farm, Well, House, Identity, Property_house, Property_farm, Crop

class IdentitySerializer(serializers.ModelSerializer):
    class Meta:
        model = Identity
        fields = ('aadhar_id','name')

    def create(self, validated_data):
        """
        Create and return a new `Snippet` instance, given the validated data.
        """
        return Identity.objects.create(**validated_data)

    def update(self, instance, validated_data):
        """
        Update and return an existing `Snippet` instance, given the validated data.
        """
        instance.aadhar_id = validated_data.get('aadhar_id', instance.aadhar_id)
        instance.name = validated_data.get('name', instance.name)
        instance.save()
        return instance

class Property_houseSerializer(serializers.ModelSerializer):
    class Meta:
        model = Property_house
        fields = ( 'a_id', 'house_id')

    def create(self, validated_data):
        """
        Create and return a new `Snippet` instance, given the validated data.
        """
        return Property_house.objects.create(**validated_data)

    def update(self, instance, validated_data):
        """
        Update and return an existing `Snippet` instance, given the validated data.
        """
        instance.a_id = validated_data.get('a_id', instance.a_id)
        instance.house_id = validated_data.get('house_id', instance.house_id)
        instance.save()
        return instance

class Property_farmSerializer(serializers.ModelSerializer):
    class Meta:
        model = Property_farm
        fields = ( 'a_id', 'farm_id')

    def create(self, validated_data):
        """
        Create and return a new `Snippet` instance, given the validated data.
        """
        return Property_farm.objects.create(**validated_data)

    def update(self, instance, validated_data):
        """
        Update and return an existing `Snippet` instance, given the validated data.
        """
        instance.a_id = validated_data.get('a_id', instance.a_id)
        instance.farm_id = validated_data.get('farm_id', instance.farm_id)
        instance.save()
        return instance

class HouseSerializer(serializers.ModelSerializer):
    class Meta:
        model = House
        fields = ('id','h_id','h_point','area','income')

    def create(self, validated_data):
        """
        Create and return a new `Snippet` instance, given the validated data.
        """
        return House.objects.create(**validated_data)

    def update(self, instance, validated_data):
        """
        Update and return an existing `Snippet` instance, given the validated data.
        """
        instance.h_id = validated_data.get('h_id', instance.h_id)
        instance.h_point = validated_data.get('h_point', instance.h_point)
        instance.area = validated_data.get('area', instance.area)
        instance.income = validated_data.get('income', instance.income)
        instance.save()
        return instance

class FarmSerializer(serializers.ModelSerializer):
    class Meta:
        model = Farm
        fields = ('id','f_id', 'poly','area')

    def create(self, validated_data):
        """
        Create and return a new `Snippet` instance, given the validated data.
        """
        return Farm.objects.create(**validated_data)

    def update(self, instance, validated_data):
        """
        Update and return an existing `Snippet` instance, given the validated data.
        """
        instance.f_id = validated_data.get('f_id', instance.f_id)
        instance.poly = validated_data.get('poly', instance.poly)
        instance.area = validated_data.get('area', instance.area)
        instance.save()
        return instance

class WellSerializer(serializers.ModelSerializer):
    class Meta:
        model = Well
        fields = ('id','w_id','w_point','depth')

    def create(self, validated_data):
        """
        Create and return a new `Snippet` instance, given the validated data.
        """
        return Well.objects.create(**validated_data)

    def update(self, instance, validated_data):
        """
        Update and return an existing `Snippet` instance, given the validated data.
        """
        instance.w_id = validated_data.get('w_id', instance.w_id)
        instance.w_point = validated_data.get('w_point', instance.w_point)
        instance.depth = validated_data.get('depth', instance.depth)
        instance.save()
        return instance

class CropSerializer(serializers.ModelSerializer):
    class Meta:
        model = Crop
        fields = ('id','c_id','name','output')

    def create(self, validated_data):
        """
        Create and return a new `Snippet` instance, given the validated data.
        """
        return Well.objects.create(**validated_data)

    def update(self, instance, validated_data):
        """
        Update and return an existing `Snippet` instance, given the validated data.
        """
        instance.c_id = validated_data.get('c_id', instance.c_id)
        instance.name = validated_data.get('name', instance.name)
        instance.output = validated_data.get('output', instance.output)
        instance.save()
        return instance
